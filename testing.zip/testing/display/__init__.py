# testing/display/__init__.py

from .timetable_view import display_timetable

__all__ = ['display_timetable']